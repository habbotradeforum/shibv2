// Animation
document.addEventListener(
  "DOMContentLoaded",
  function () {
    // alert("Ready!");
    function obCallback(payload) {
      // console.log(payload);
      payload.forEach((entry) => {
        // Each entry describes an intersection change for one observed
        // target element:
        //   entry.boundingClientRect
        //   entry.intersectionRatio
        //   entry.intersectionRect
        //   entry.isIntersecting
        //   entry.rootBounds
        //   entry.target
        //   entry.time
        if (entry.isIntersecting) {
          console.log("@@@@@@@@@@@@@@@");
          console.log(entry.boundingClientRect);
          console.log(entry.intersectionRatio);
          console.log(entry.intersectionRect);
          console.log(entry.isIntersecting);
          console.log(entry.rootBounds);
          console.log(entry.target);
          console.log(entry.target.id);
        }

        if (entry.target.id === "product") {
          const titleAnimationHost = document.getElementById(
            "product-section-title-animation-host"
          );
          const imageAnimationHost = document.getElementById(
            "product-section-image-animation-host"
          );
          // is intersecting
          if (entry.isIntersecting) {
            titleAnimationHost.classList.add("animate__fadeInLeft");
            imageAnimationHost.classList.add("animate__fadeInRight");
          } else {
            if (titleAnimationHost.classList.contains("animate__fadeInLeft")) {
              titleAnimationHost.classList.remove("animate__fadeInLeft");
            }

            if (imageAnimationHost.classList.contains("animate__fadeInRight")) {
              imageAnimationHost.classList.remove("animate__fadeInRight");
            }
          }
        }

        if (entry.target.id === "careers") {
          const titleAnimationHost = document.getElementById(
            "careers-section-title-animation-host"
          );
          const imageAnimationHost = document.getElementById(
            "careers-section-image-animation-host"
          );

          if (entry.isIntersecting) {
            titleAnimationHost.classList.add("animate__fadeInRight");
            imageAnimationHost.classList.add("animate__fadeInLeft");
          } else {
            if (titleAnimationHost.classList.contains("animate__fadeInRight")) {
              titleAnimationHost.classList.remove("animate__fadeInRight");
            }
            if (imageAnimationHost.classList.contains("animate__fadeInLeft")) {
              imageAnimationHost.classList.remove("animate__fadeInLeft");
            }
          }
        }

        if (entry.target.id === "about-us") {
          const titleAnimationHost = document.getElementById(
            "about-us-section-title-animation-host"
          );
          const gridAnimationHost = document.getElementById(
            "about-us-section-grid-animation-host"
          );
          if (entry.isIntersecting) {
            titleAnimationHost.classList.add("animate__slideInDown");
            gridAnimationHost.classList.add("animate__zoomIn");
          } else {
            if (titleAnimationHost.classList.contains("animate__slideInDown")) {
              titleAnimationHost.classList.remove("animate__slideInDown");
            }
            if (gridAnimationHost.classList.contains("animate__zoomIn")) {
              gridAnimationHost.classList.remove("animate__zoomIn");
            }
          }
        }

        if (entry.target.id === "pricing") {
          const titleAnimationHost = document.getElementById(
            "pricing-section-title-animation-host"
          );
          const capsuleOneAnimationHost = document.getElementById(
            "pricing-section-capsule-one-container-animation-host"
          );
          const capsuleTwoAnimationHost = document.getElementById(
            "pricing-section-capsule-two-container-animation-host"
          );
          const capsuleThreeAnimationHost = document.getElementById(
            "pricing-section-capsule-three-container-animation-host"
          );

          if (entry.isIntersecting) {
            titleAnimationHost.classList.add("animate__slideInDown");
            capsuleOneAnimationHost.classList.add("animate__slideInLeft");
            capsuleTwoAnimationHost.classList.add("animate__zoomIn");
            capsuleThreeAnimationHost.classList.add("animate__slideInRight");
          } else {
            if (titleAnimationHost.classList.contains("animate__slideInDown")) {
              titleAnimationHost.classList.remove("animate__slideInDown");
            }
            if (
              capsuleOneAnimationHost.classList.contains("animate__slideInLeft")
            ) {
              capsuleOneAnimationHost.classList.remove("animate__slideInLeft");
            }

            if (capsuleTwoAnimationHost.classList.contains("animate__zoomIn")) {
              capsuleTwoAnimationHost.classList.remove("animate__zoomIn");
            }

            if (
              capsuleThreeAnimationHost.classList.contains(
                "animate__slideInRight"
              )
            ) {
              capsuleThreeAnimationHost.classList.remove(
                "animate__slideInRight"
              );
            }
          }
        }
      });
    }
    const observer = new IntersectionObserver(obCallback);

    observer.observe(document.querySelector("#pricing"));
    observer.observe(document.querySelector("#product"));
    observer.observe(document.querySelector("#about-us"));
    observer.observe(document.querySelector("#careers"));

    setupScrollListener();
    setupScrollEvent();

    document.querySelectorAll(".scene").forEach((elem) => {
      const modifier = elem.getAttribute("data-modifier");

      basicScroll
        .create({
          elem: elem,
          from: 0,
          to: 519,
          direct: true,
          props: {
            "--translateY": {
              from: "0",
              to: `${10 * modifier}px`,
            },
          },
        })
        .start();
    });

    console.log("onLoad");
  },
  false
);

// scrolls window to top
function setupScrollEvent() {
  const scrollButton = document.querySelector(".scroll-top");

  scrollButton.addEventListener("click", (e) => {
    // not the best solution until Safari/Edge support scroll behavior
    // window.scrollTo({ top: 0, behavior: 'smooth' });
    e.preventDefault();
    $("html, body").animate({ scrollTop: 0 }, "300");
  });
}

// prepares the window for a scroll event to show the scroll button
function setupScrollListener() {
  // gets the breakpoint at which the scroll-to-top button should appear
  const scrollBreakpoint = window.innerHeight * 0.9;

  window.addEventListener("scroll", (e) => {
    const scrollButton = document.querySelector(".scroll-top");

    // const scrollOffset = document.scrollingElement.scrollTop;
    const scrollOffset = window.scrollY;

    if (scrollOffset >= scrollBreakpoint) {
      scrollButton.classList.add("visible");
    } else if (scrollOffset <= 0) {
      scrollButton.classList.remove("visible");
    }
  });
}
